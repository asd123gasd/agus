// scripts/auth/session.js (Versión Definitiva, Completa y Robusta)
import { db } from '../firebase-config.js';
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

const auth = getAuth();

/**
 * Revisa el estado de autenticación y busca los datos del taller en Firestore.
 * Es el punto central de control de permisos de la aplicación.
 * @returns {Promise<object>} Una promesa que resuelve con un objeto que contiene los datos del usuario y sus permisos.
 */
export function checkAuthStatus() {
    return new Promise((resolve, reject) => {
        // onAuthStateChanged devuelve una función para desuscribirse, la guardamos.
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            // Una vez que tenemos una respuesta (sea usuario o null), nos desuscribimos para evitar fugas de memoria.
            unsubscribe(); 
            
            if (user) {
                // Si hay un usuario, intentamos obtener los datos de su taller.
                try {
                    const tallerDocRef = doc(db, "talleres", user.uid);
                    const tallerDocSnap = await getDoc(tallerDocRef);

                    if (tallerDocSnap.exists()) {
                        const tallerData = tallerDocSnap.data();
                        
                        // Calculamos los permisos basados en el "contrato" del taller.
                        const hoy = new Date();
                        const fechaFinTrial = tallerData.fechaFinTrial.toDate();
                        const isTrialActive = tallerData.estadoSuscripcion === "TRIAL_ACTIVO" && hoy < fechaFinTrial;
                        const isPremium = tallerData.plan === "PREMIUM"; // Preparado para el futuro

                        // Resolvemos la promesa con un objeto completo.
                        resolve({
                            isLoggedIn: true,
                            user: user,
                            tallerData: tallerData,
                            hasPremiumAccess: isPremium || isTrialActive,
                            daysRemaining: isTrialActive ? Math.ceil((fechaFinTrial - hoy) / (1000 * 60 * 60 * 24)) : 0
                        });
                    } else {
                        // Caso raro: usuario existe en Auth pero no en Firestore.
                        // Lo tratamos como un usuario logueado pero sin permisos.
                        resolve({ isLoggedIn: true, user: user, tallerData: null, hasPremiumAccess: false });
                    }
                } catch (error) {
                    // Si hay un error al leer Firestore, rechazamos la promesa.
                    console.error("Error al buscar los datos del taller:", error);
                    reject(error);
                }
            } else {
                // No hay nadie logueado, resolvemos con el estado de "no logueado".
                resolve({ isLoggedIn: false, user: null, tallerData: null, hasPremiumAccess: false });
            }
        }, (error) => {
            // Si hay un error en el propio servicio de autenticación, rechazamos la promesa.
            console.error("Error en el observador de autenticación:", error);
            reject(error);
        });
    });
}