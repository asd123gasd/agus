import { db } from '../firebase-config.js'; // <-- ESTA ES LA LÍNEA CORREGIDA
import { 
    getAuth, 
    signInWithEmailAndPassword, 
    onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";

document.addEventListener('DOMContentLoaded', () => {
    const auth = getAuth();
    const loginForm = document.getElementById('login-form');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const loginButton = document.getElementById('login-button');
    const errorMessageDiv = document.getElementById('error-message');

    onAuthStateChanged(auth, (user) => {
        if (user) {
            window.location.href = '../escritorio.html';
        }
    });

    const setButtonLoading = (isLoading) => {
        const span = loginButton.querySelector('span');
        const spinner = loginButton.querySelector('.spinner');
        if (isLoading) {
            loginButton.disabled = true;
            span.style.display = 'none';
            spinner.style.display = 'block';
        } else {
            loginButton.disabled = false;
            span.style.display = 'inline';
            spinner.style.display = 'none';
        }
    };

    const showErrorMessage = (message) => {
        errorMessageDiv.textContent = message;
        errorMessageDiv.style.display = 'block';
    };

    const hideErrorMessage = () => {
        errorMessageDiv.style.display = 'none';
    };

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('status') === 'registered') {
        alert("¡Cuenta creada con éxito! Por favor, inicia sesión.");
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            hideErrorMessage();
            setButtonLoading(true);
            const email = emailInput.value.trim();
            const password = passwordInput.value.trim();
            try {
                await signInWithEmailAndPassword(auth, email, password);
            } catch (error) {
                let friendlyMessage = "Ocurrió un error. Inténtalo de nuevo.";
                switch (error.code) {
                    case 'auth/user-not-found':
                    case 'auth/wrong-password':
                    case 'auth/invalid-credential':
                        friendlyMessage = "Correo o contraseña incorrectos.";
                        break;
                    case 'auth/invalid-email':
                        friendlyMessage = "El formato del correo electrónico no es válido.";
                        break;
                    case 'auth/too-many-requests':
                        friendlyMessage = "Acceso bloqueado por demasiados intentos. Intenta más tarde.";
                        break;
                }
                showErrorMessage(friendlyMessage);
            } finally {
                setButtonLoading(false);
            }
        });
    }
});