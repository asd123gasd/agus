import { db } from './firebase-config.js';
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', () => {
    const auth = getAuth();
    const registerForm = document.getElementById('register-form');
    const tallerNameInput = document.getElementById('tallerName');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const termsCheckbox = document.getElementById('terms');
    const registerButton = document.getElementById('register-button');
    const errorMessageDiv = document.getElementById('error-message');

    const setButtonLoading = (isLoading) => {
        const span = registerButton.querySelector('span');
        const spinner = registerButton.querySelector('.spinner');
        if (isLoading) {
            registerButton.disabled = true;
            span.style.display = 'none';
            spinner.style.display = 'block';
        } else {
            registerButton.disabled = false;
            span.style.display = 'inline';
            spinner.style.display = 'none';
        }
    };

    const showErrorMessage = (message) => {
        errorMessageDiv.textContent = message;
        errorMessageDiv.style.display = 'block';
    };

    const hideErrorMessage = () => {
        errorMessageDiv.style.display = 'none';
    };

    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            hideErrorMessage();

            if (!termsCheckbox.checked) {
                showErrorMessage("Debes aceptar los términos y condiciones.");
                return;
            }
            
            setButtonLoading(true);

            const tallerName = tallerNameInput.value.trim();
            const email = emailInput.value.trim();
            const password = passwordInput.value.trim();

            try {
                // 1. Crear el usuario en Firebase Authentication
                const userCredential = await createUserWithEmailAndPassword(auth, email, password);
                const user = userCredential.user;

                // 2. Crear el "contrato" de la Beta en Firestore
                const trialEndDate = new Date();
                trialEndDate.setDate(trialEndDate.getDate() + 30); // 30 días de prueba

                await setDoc(doc(db, "talleres", user.uid), {
                    nombreTaller: tallerName,
                    email: user.email,
                    plan: "BETA",
                    estadoSuscripcion: "TRIAL_ACTIVO",
                    fechaRegistro: serverTimestamp(),
                    fechaFinTrial: trialEndDate
                });

                console.log("Usuario registrado y contrato creado con éxito:", user.uid);
                
                // 3. Redirigir al login con un mensaje de éxito
                window.location.href = `login.html?status=registered`;

            } catch (error) {
                console.error("Error en el registro:", error.code);
                let friendlyMessage = "Ocurrió un error. Inténtalo de nuevo.";
                
                switch (error.code) {
                    case 'auth/email-already-in-use':
                        friendlyMessage = "Este correo electrónico ya está registrado.";
                        break;
                    case 'auth/invalid-email':
                        friendlyMessage = "El formato del correo no es válido.";
                        break;
                    case 'auth/weak-password':
                        friendlyMessage = "La contraseña debe tener al menos 6 caracteres.";
                        break;
                }
                showErrorMessage(friendlyMessage);
            } finally {
                setButtonLoading(false);
            }
        });
    }
});