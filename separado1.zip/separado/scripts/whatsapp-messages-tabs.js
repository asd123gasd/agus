// scripts/whatsapp-messages-tabs.js (VERSIÓN CORREGIDA Y AISLADA)

document.addEventListener('DOMContentLoaded', () => {
    // Seleccionamos el contenedor de pestañas específico de WhatsApp por su ID
    const whatsappTabsContainer = document.getElementById('whatsapp-tabs-container');

    // Si no existe este contenedor en la página, no hacemos nada más.
    if (!whatsappTabsContainer) {
        return;
    }

    // Buscamos los botones y paneles DENTRO de nuestro contenedor de WhatsApp
    const tabButtons = whatsappTabsContainer.querySelectorAll('.tab-button');
    const tabPanelsContainer = whatsappTabsContainer.querySelector('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Obtenemos el ID del panel que este botón debe mostrar
            const tabIdToShow = button.dataset.tab;

            // 1. Quitar la clase 'active' de TODOS los botones de ESTE contenedor
            tabButtons.forEach(btn => {
                btn.classList.remove('active');
            });

            // 2. Añadir la clase 'active' SOLO al botón que se hizo clic
            button.classList.add('active');

            // 3. Ocultar TODOS los paneles de ESTE contenedor
            tabPanelsContainer.querySelectorAll('.tab-panel').forEach(panel => {
                panel.classList.remove('active');
            });

            // 4. Mostrar SOLO el panel correspondiente al botón que se hizo clic
            const panelToShow = document.getElementById(tabIdToShow);
            if (panelToShow) {
                panelToShow.classList.add('active');
            }
        });
    });

    // Activar la primera pestaña por defecto al cargar la página
    if (tabButtons.length > 0 && !whatsappTabsContainer.querySelector('.tab-button.active')) {
        tabButtons[0].click();
    }
});