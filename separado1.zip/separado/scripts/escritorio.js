// scripts/escritorio.js (Versión Final sin localStorage)
import { db } from './firebase-config.js';
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { collection, query, where, onSnapshot, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', () => {
    const auth = getAuth();
    
    onAuthStateChanged(auth, (user) => {
        if (user) {
            runDashboardLogic(user);
        } else {
            console.log("Usuario no autenticado en el escritorio.");
        }
    });
});

async function runDashboardLogic(currentUser) {
    const searchInput = document.getElementById('global-search-input');
    const searchResultsContainer = document.getElementById('global-search-results');
    const searchForm = document.getElementById('global-search-form');
    let allRemitos = []; 

    // La consulta siempre filtra los remitos por el tallerId del usuario actual
    const remitosQuery = query(
        collection(db, "remitos"), 
        where("tallerId", "==", currentUser.uid),
        where("archivado", "==", false)
    );

    onSnapshot(remitosQuery, (querySnapshot) => {
        allRemitos = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        updateInicioDashboard(allRemitos);
        updateFinancialSummary(allRemitos);
    }, (error) => {
        console.error("Error al escuchar los cambios en los remitos: ", error);
    });
    
    // ===== LÓGICA PARA LA IMAGEN DE PUBLICIDAD ELIMINADA =====
    // Como solicitaste, ya no se intenta cargar nada desde localStorage aquí.
    const desktopAdContainer = document.getElementById('desktop-ad-container');
    const tallerDocRef = doc(db, "talleres", currentUser.uid);
    const tallerDocSnap = await getDoc(tallerDocRef);
    if (tallerDocSnap.exists() && tallerDocSnap.data().adUrl) {
         desktopAdContainer.innerHTML = `<img src="${tallerDocSnap.data().adUrl}" alt="Publicidad del escritorio">`;
    } else {
         desktopAdContainer.innerHTML = `<img src="https://placehold.co/600x400/0F172A/3B82F6?text=Sube+tu+imagen\\ndesde+Mi+Perfil" alt="Espacio para publicidad">`;
    }


    if (searchInput && searchResultsContainer) {
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase().trim();
            if (searchTerm.length < 2) {
                searchResultsContainer.classList.add('hidden');
                searchResultsContainer.innerHTML = '';
                return;
            }
            const filteredResults = allRemitos.filter(r => 
                (String(r.clienteNombre) || '').toLowerCase().includes(searchTerm) || 
                (String(r.numeroRemito) || '').toLowerCase().includes(searchTerm) ||
                (String(r.equipoMarca) || '').toLowerCase().includes(searchTerm) ||
                (String(r.equipoModelo) || '').toLowerCase().includes(searchTerm)
            ).slice(0, 7);
            displayResults(filteredResults);
        });

        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-wrapper')) {
                searchResultsContainer.classList.add('hidden');
            }
        });
    }

    if(searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const searchTerm = searchInput.value.trim();
            if(searchTerm) {
                window.location.href = `registros.html?search=${encodeURIComponent(searchTerm)}`;
            }
        });
    }

    function displayResults(results) {
        searchResultsContainer.innerHTML = '';
        if (results.length === 0) {
            searchResultsContainer.classList.add('hidden');
            return;
        }
        results.forEach(remito => {
            const resultItem = document.createElement('a');
            resultItem.href = `detalles-remito.html?id=${remito.id}`;
            resultItem.classList.add('search-result-item');
            const estado = remito.estadoReparacion || 'Recibido';
            resultItem.innerHTML = `
                <div class="result-info">
                    <span class="result-title">#${remito.numeroRemito} - ${remito.clienteNombre}</span>
                    <span class="result-subtitle">${remito.equipoMarca} ${remito.equipoModelo}</span>
                </div>
                <div class="result-status">
                    <span class="status-badge" data-estado="${estado}">${estado}</span>
                </div>
            `;
            searchResultsContainer.appendChild(resultItem);
        });
        searchResultsContainer.classList.remove('hidden');
    }
    
    const statTotalInicio = document.getElementById('stat-total-inicio');
    const statListosInicio = document.getElementById('stat-listos-inicio');
    const statHoyInicio = document.getElementById('stat-hoy-inicio');
    const equiposTallerList = document.getElementById('equipos-taller-list')?.querySelector('ul');
    const listosRetirarList = document.getElementById('listos-retirar-list')?.querySelector('ul');
    const ingresosHoyList = document.getElementById('ingresos-hoy-list')?.querySelector('ul');

    function updateFinancialSummary(remitos) {
        const presupuestosAmountEl = document.getElementById('presupuestos-amount');
        if (presupuestosAmountEl) {
            const totalPorAprobar = remitos
                .filter(r => r.estadoReparacion === 'Esperando aprobación' && r.presupuesto > 0)
                .reduce((sum, r) => sum + (parseFloat(r.presupuesto) || 0), 0);
            presupuestosAmountEl.textContent = new Intl.NumberFormat('es-AR', {
                style: 'currency', currency: 'ARS'
            }).format(totalPorAprobar);
        }
    
        const cajaAmountEl = document.getElementById('caja-amount');
        const cajaTrendEl = document.getElementById('caja-trend');
        const cajaTrendIconEl = document.getElementById('caja-trend-icon');
        const cajaTrendTextEl = document.getElementById('caja-trend-text');
    
        if (cajaAmountEl && cajaTrendEl && cajaTrendTextEl && cajaTrendIconEl) {
            const hoy = new Date();
            hoy.setHours(0, 0, 0, 0);
            const ayer = new Date();
            ayer.setDate(ayer.getDate() - 1);
            ayer.setHours(0, 0, 0, 0);
    
            const ingresosHoy = remitos
                .filter(r => {
                    const fechaEntrega = r.fechaEntrega?.toDate();
                    return r.estadoReparacion === 'Entregado' && fechaEntrega && fechaEntrega.getTime() >= hoy.getTime();
                })
                .reduce((sum, r) => sum + (parseFloat(r.presupuesto) || 0), 0);
            
            const ingresosAyer = remitos
                .filter(r => {
                    const fechaEntrega = r.fechaEntrega?.toDate();
                    return r.estadoReparacion === 'Entregado' && fechaEntrega && fechaEntrega.getTime() >= ayer.getTime() && fechaEntrega.getTime() < hoy.getTime();
                })
                .reduce((sum, r) => sum + (parseFloat(r.presupuesto) || 0), 0);
    
            cajaAmountEl.textContent = new Intl.NumberFormat('es-AR', {
                style: 'currency', currency: 'ARS'
            }).format(ingresosHoy);
    
            let porcentajeCambio = 0;
            if (ingresosAyer > 0) {
                porcentajeCambio = ((ingresosHoy - ingresosAyer) / ingresosAyer) * 100;
            } else if (ingresosHoy > 0) {
                porcentajeCambio = 100;
            }
    
            cajaTrendTextEl.textContent = `${porcentajeCambio.toFixed(1)}%`;
    
            if (porcentajeCambio >= 0) {
                cajaTrendEl.className = 'card-pro-trend-up';
                cajaTrendIconEl.className = 'fas fa-arrow-up';
            } else {
                cajaTrendEl.className = 'card-pro-trend-down';
                cajaTrendIconEl.className = 'fas fa-arrow-down';
            }
        }
    }

    function updateInicioDashboard(remitos) {
        if (!statTotalInicio) return;
        const estadosEnTaller = ['Recibido', 'En revisión', 'Esperando repuesto', 'Esperando aprobación', 'Reparado'];
        const totalEquipos = remitos.filter(r => estadosEnTaller.includes(r.estadoReparacion));
        const listosParaRetirar = remitos.filter(r => r.estadoReparacion === 'Listo para retirar');
        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const ingresosHoy = remitos.filter(r => r.fechaCreacion?.toDate()?.setHours(0, 0, 0, 0) === hoy.getTime());

        statTotalInicio.textContent = totalEquipos.length;
        statListosInicio.textContent = listosParaRetirar.length;
        statHoyInicio.textContent = ingresosHoy.length;
        
        renderEquipoList(equiposTallerList, totalEquipos);
        renderEquipoList(listosRetirarList, listosParaRetirar);
        renderEquipoList(ingresosHoyList, ingresosHoy);
    }

    function renderEquipoList(ulElement, equipos) {
        if (!ulElement) return;
        ulElement.innerHTML = '';
        if (equipos.length === 0) {
            ulElement.innerHTML = '<li>No hay equipos.</li>';
            return;
        }
        equipos.slice(0, 5).forEach(equipo => {
            const li = document.createElement('li');
            li.textContent = `${equipo.clienteNombre || 'N/A'} - ${equipo.equipoMarca || ''} ${equipo.equipoModelo || ''}`;
            ulElement.appendChild(li);
        });
    }
}