// scripts/imprimir.js
import { db } from './firebase-config.js';
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', async () => {
    // Lee el ID del remito desde los parámetros de la URL
    const urlParams = new URLSearchParams(window.location.search);
    const remitoId = urlParams.get('id');

    if (!remitoId) {
        document.body.innerHTML = '<h1>Error: No se encontró un ID de remito para imprimir.</h1>';
        return;
    }

    try {
        // Busca el remito en la base de datos
        const remitoDocRef = doc(db, "remitos", remitoId);
        const remitoDocSnap = await getDoc(remitoDocRef);

        if (!remitoDocSnap.exists()) {
            document.body.innerHTML = '<h1>Error: El remito solicitado no existe.</h1>';
            return;
        }

        const datos = remitoDocSnap.data();
        
        // Obtiene el nombre del Taller desde la base de datos
        let nombreDelTaller = 'Nombre de tu Taller'; // Valor por defecto
        if (datos.tallerId) {
            const tallerDocRef = doc(db, "talleres", datos.tallerId);
            const tallerDocSnap = await getDoc(tallerDocRef);
            if (tallerDocSnap.exists()) {
                nombreDelTaller = tallerDocSnap.data().nombreTaller || nombreDelTaller;
            }
        }
        document.getElementById('nombre-empresa').textContent = nombreDelTaller;

        const fecha = datos.fechaCreacion ? new Date(datos.fechaCreacion.seconds * 1000) : new Date();
        const fechaFormateada = fecha.toLocaleDateString('es-AR');

        // Llenar datos principales del remito
        document.getElementById('remito-numero').textContent = datos.numeroRemito || 'N/A';
        document.getElementById('remito-fecha').textContent = fechaFormateada;
        document.getElementById('equipo-tipo').textContent = datos.equipoTipo || 'N/A';
        document.getElementById('equipo-marca').textContent = datos.equipoMarca || 'N/A';
        document.getElementById('equipo-modelo').textContent = datos.equipoModelo || 'N/A';
        document.getElementById('equipo-serie').textContent = datos.equipoSerie || 'N/A';
        document.getElementById('descripcion-falla').textContent = datos.descripcionFalla || 'N/A';
        document.getElementById('observaciones-adicionales').textContent = datos.estadoCelular || 'Ninguna';
        document.getElementById('cliente-nombre').textContent = datos.clienteNombre || 'N/A';
        document.getElementById('cliente-telefono').textContent = datos.clienteTelefono || 'N/A';
        document.getElementById('cliente-email').textContent = datos.clienteEmail || 'N/A';
        
        const diagnosticoLista = document.getElementById('diagnostico-lista');
        diagnosticoLista.innerHTML = '';
        const chequeos = [
            datos.diagnosticoCarga, 
            datos.diagnosticoEnciende, 
            datos.diagnosticoGolpeado, 
            datos.diagnosticoMojado
        ];
        chequeos.forEach(key => {
            if (key && key !== 'Sin Verificar') {
                const li = document.createElement('li');
                li.textContent = key;
                diagnosticoLista.appendChild(li);
            }
        });

        // Llenar datos del talonario
        document.getElementById('cliente-nombre-talon').textContent = datos.clienteNombre || 'Cliente';
        document.getElementById('remito-fecha-talon').textContent = fechaFormateada;
        document.getElementById('equipo-info-talon').textContent = `${datos.equipoMarca || ''} ${datos.equipoModelo || ''}`;
        document.getElementById('remito-numero-talon').textContent = datos.numeroRemito || 'N/A';
        
        const qrContainer = document.getElementById("qrcode");
        if(qrContainer) {
            // DEBES REEMPLAZAR "tusitio.com" por tu dominio real
            const urlEstado = `https://tusitio.com/estado?id=${datos.numeroRemito}`; 
            new QRCode(qrContainer, { text: urlEstado, width: 80, height: 80 });
        }

        setTimeout(() => window.print(), 500);

    } catch (error) {
        console.error("Error al generar la página de impresión:", error);
        document.body.innerHTML = '<h1>Error al conectar con la base de datos.</h1>';
    }
});