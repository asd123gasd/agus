// scripts/inventario.js (Versión con Conexión a Proveedores)
import { db } from './firebase-config.js';
import { checkAuthStatus } from './auth/session.js';
import {
    collection, query, where, orderBy, getDocs, doc, addDoc, updateDoc, deleteDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', async () => {
    const tableContainer = document.querySelector('.table-container');
    const premiumWall = document.getElementById('premium-wall');

    const session = await checkAuthStatus();

    if (!session.isLoggedIn) {
        window.location.href = '../auth/login.html';
        return;
    }
    
    if (session.hasPremiumAccess) {
        tableContainer.style.display = 'block';
        premiumWall.style.display = 'none';
        runInventoryLogic(session.user);
    } else {
        tableContainer.style.display = 'none';
        premiumWall.style.display = 'block';
    }
});

function runInventoryLogic(currentUser) {
    const loader = document.getElementById('loader');
    const openModalBtn = document.getElementById('btn-open-modal');
    const searchInput = document.getElementById('searchInput');
    const summaryTotalValueEl = document.getElementById('total-value');
    const summaryLowStockEl = document.getElementById('low-stock-items');
    const summaryUniqueItemsEl = document.getElementById('unique-items');
    const tableViewBtn = document.getElementById('table-view-btn');
    const gridViewBtn = document.getElementById('grid-view-btn');
    const tableViewContainer = document.getElementById('inventory-table-view');
    const gridViewContainer = document.getElementById('inventory-grid-view');
    const tableBody = document.getElementById('inventory-table-body');
    const modal = document.getElementById('item-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelModalBtn = document.getElementById('modal-cancel-btn');
    const saveModalBtn = document.getElementById('modal-save-btn');
    const itemForm = document.getElementById('item-form');
    const modalTitle = document.getElementById('modal-title');
    const itemIdInput = document.getElementById('item-id');
    const supplierSelect = document.getElementById('item-supplier'); // ✨ Selector para el nuevo campo

    let fullInventory = [];
    let suppliers = []; // ✨ Array para guardar los proveedores

    // ===== FUNCIÓN MODIFICADA: Carga inventario Y proveedores =====
    async function loadData() {
        if (!currentUser) return;
        loader.style.display = 'flex';
        
        try {
            // Cargar proveedores primero
            const suppliersQuery = query(collection(db, "proveedores"), where("tallerId", "==", currentUser.uid), orderBy("nombre"));
            const suppliersSnapshot = await getDocs(suppliersQuery);
            suppliers = suppliersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            populateSupplierSelect(); // Llena el menú desplegable del modal

            // Cargar inventario
            const inventoryQuery = query(collection(db, "inventario"), where("tallerId", "==", currentUser.uid), orderBy("nombre"));
            const inventorySnapshot = await getDocs(inventoryQuery);
            fullInventory = inventorySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            
            updateSummaryDashboard(fullInventory);
            renderViews();

        } catch (error) {
            console.error("Error cargando datos: ", error);
            tableBody.innerHTML = `<tr><td colspan="6">Error al cargar los datos.</td></tr>`;
        } finally {
            loader.style.display = 'none';
        }
    }

    // ===== NUEVA FUNCIÓN: Llena el select de proveedores =====
    function populateSupplierSelect() {
        supplierSelect.innerHTML = '<option value="">Sin Proveedor</option>'; // Opción por defecto
        suppliers.forEach(supplier => {
            const option = document.createElement('option');
            option.value = supplier.id;
            option.textContent = supplier.nombre;
            supplierSelect.appendChild(option);
        });
    }
    
    // ... (updateSummaryDashboard no cambia) ...
    function updateSummaryDashboard(items) {
        const totalValue = items.reduce((sum, item) => sum + (item.stock * item.precioCosto), 0);
        const lowStockItems = items.filter(item => item.stockMinimo > 0 && item.stock <= item.stockMinimo).length;
        const uniqueItems = items.length;
        summaryTotalValueEl.textContent = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(totalValue);
        summaryLowStockEl.textContent = lowStockItems;
        summaryUniqueItemsEl.textContent = uniqueItems;
    }

    // ===== FUNCIÓN MODIFICADA: renderGridView muestra el proveedor =====
    function renderGridView(items) {
        gridViewContainer.innerHTML = '';
        if (items.length === 0) {
            gridViewContainer.innerHTML = `<p style="grid-column: 1 / -1; text-align: center;">No se encontraron resultados.</p>`;
            return;
        }
        items.forEach(item => {
            // ... (lógica de stock y porcentaje no cambia) ...
            const stock = item.stock || 0;
            const minStock = item.stockMinimo || 0;
            let stockStatus = 'high';
            let stockPercentage = 100;
            if (minStock > 0) {
                if (stock <= minStock) stockStatus = 'low';
                else if (stock <= minStock * 1.5) stockStatus = 'medium';
                stockPercentage = Math.min((stock / (minStock * 2)) * 100, 100);
            }

            const supplier = suppliers.find(s => s.id === item.supplierId);
            const supplierName = supplier ? supplier.nombre : 'Sin Proveedor';

            const card = document.createElement('div');
            card.className = 'inventory-card';
            card.innerHTML = `
                <div class="card-header">
                    <div class="card-image-placeholder"><i class="fas fa-box"></i></div>
                    <div class="card-title-group">
                        <h3 class="card-title">${item.nombre}</h3>
                        <span class="card-sku">${item.sku || 'Sin SKU'}</span>
                        <span class="card-supplier">${supplierName}</span> </div>
                </div>
                <div class="card-stock-details">
                    <div class="card-stock-info">
                        <span>Stock</span>
                        <span>${stock} Unidades</span>
                    </div>
                    <div class="stock-bar-container">
                        <div class="stock-bar ${stockStatus}" style="width: ${stockPercentage}%;"></div>
                    </div>
                </div>
                <div class="card-footer">
                    <span class="card-price">${new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(item.precioCosto)}</span>
                    <div class="card-actions">
                        <button class="btn-action-edit" data-id="${item.id}" title="Editar"><i class="fas fa-edit"></i></button>
                        <button class="btn-action-delete" data-id="${item.id}" title="Eliminar"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            `;
            gridViewContainer.appendChild(card);
        });
    }

    // ===== FUNCIÓN MODIFICADA: renderTableView muestra el proveedor =====
    function renderTableView(items) {
        tableBody.innerHTML = '';
        if (items.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="6" style="text-align: center;">No se encontraron resultados.</td></tr>`;
            return;
        }
        items.forEach(item => {
            // ... (lógica de stock no cambia) ...
            const stock = item.stock || 0;
            const minStock = item.stockMinimo || 0;
            let stockStatus = 'high';
            if (minStock > 0) {
                if (stock <= minStock) stockStatus = 'low';
                else if (stock <= minStock * 1.5) stockStatus = 'medium';
            }
            
            const costFormatted = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(item.precioCosto);
            const supplier = suppliers.find(s => s.id === item.supplierId);
            const supplierName = supplier ? supplier.nombre : 'N/A';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.nombre}</td>
                <td>${item.sku || 'N/A'}</td>
                <td>${supplierName}</td> <td><span class="stock-indicator ${stockStatus}">${stock}</span></td>
                <td>${costFormatted}</td>
                <td class="action-buttons-cell">
                    <button class="btn-action-edit" data-id="${item.id}" title="Editar"><i class="fas fa-edit"></i></button>
                    <button class="btn-action-delete" data-id="${item.id}" title="Eliminar"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    // ... (renderViews no cambia) ...
    function renderViews() {
        const searchTerm = searchInput.value.toLowerCase();
        const filteredItems = fullInventory.filter(item => {
            return item.nombre.toLowerCase().includes(searchTerm) || (item.sku && item.sku.toLowerCase().includes(searchTerm));
        });
        renderTableView(filteredItems);
        renderGridView(filteredItems);
    }
    
    // ===== FUNCIÓN MODIFICADA: saveItem guarda el ID del proveedor =====
    async function saveItem(e) {
        e.preventDefault();
        if (!itemForm.checkValidity()) {
            itemForm.reportValidity();
            return;
        }
        setSaveButtonLoading(true);

        const itemId = itemIdInput.value;
        const itemData = {
            nombre: document.getElementById('item-name').value.trim(),
            sku: document.getElementById('item-sku').value.trim(),
            stock: parseInt(document.getElementById('item-stock').value),
            stockMinimo: parseInt(document.getElementById('item-min-stock').value) || 0,
            precioCosto: parseFloat(document.getElementById('item-cost').value),
            supplierId: supplierSelect.value, // ✨ Guarda el ID del proveedor ✨
            ultimaModificacion: serverTimestamp()
        };

        try {
            if (itemId) {
                await updateDoc(doc(db, "inventario", itemId), itemData);
            } else {
                itemData.tallerId = currentUser.uid;
                itemData.fechaCreacion = serverTimestamp();
                await addDoc(collection(db, "inventario"), itemData);
            }
            closeModal();
            loadData(); // Recarga ambos, inventario y proveedores
        } catch (error) {
            console.error("Error guardando el repuesto: ", error);
            alert("Ocurrió un error al guardar.");
        } finally {
            setSaveButtonLoading(false);
        }
    }

    // ... (deleteItem no cambia) ...
    async function deleteItem(itemId) {
        if (!confirm("¿Estás seguro de que quieres eliminar este repuesto?")) return;
        try {
            await deleteDoc(doc(db, "inventario", itemId));
            loadData();
        } catch (error) {
            console.error("Error eliminando el repuesto: ", error);
            alert("Ocurrió un error al eliminar.");
        }
    }

    // ... (openModalForNew no cambia) ...
    function openModalForNew() {
        modalTitle.textContent = "Agregar Nuevo Repuesto";
        itemForm.reset();
        itemIdInput.value = '';
        modal.classList.add('visible');
    }

    // ===== FUNCIÓN MODIFICADA: openModalForEdit selecciona el proveedor correcto =====
    function openModalForEdit(itemId) {
        const item = fullInventory.find(i => i.id === itemId);
        if (!item) return;

        modalTitle.textContent = "Editar Repuesto";
        itemForm.reset();
        
        itemIdInput.value = item.id;
        document.getElementById('item-name').value = item.nombre;
        document.getElementById('item-sku').value = item.sku || '';
        document.getElementById('item-stock').value = item.stock;
        document.getElementById('item-min-stock').value = item.stockMinimo || '';
        document.getElementById('item-cost').value = item.precioCosto;
        supplierSelect.value = item.supplierId || ''; // ✨ Selecciona el proveedor ✨

        modal.classList.add('visible');
    }

    // ... (resto de funciones y listeners no cambian) ...
    function closeModal() { modal.classList.remove('visible'); }
    function setSaveButtonLoading(isLoading) {
        const text = saveModalBtn.querySelector('span');
        const spinner = saveModalBtn.querySelector('.spinner');
        if (isLoading) {
            saveModalBtn.disabled = true;
            text.style.display = 'none';
            spinner.style.display = 'block';
        } else {
            saveModalBtn.disabled = false;
            text.style.display = 'inline';
            spinner.style.display = 'none';
        }
    }
    openModalBtn.addEventListener('click', openModalForNew);
    closeModalBtn.addEventListener('click', closeModal);
    cancelModalBtn.addEventListener('click', closeModal);
    itemForm.addEventListener('submit', saveItem);
    searchInput.addEventListener('input', renderViews);
    function handleActionClick(event) {
        const target = event.target.closest('button');
        if (!target) return;
        const id = target.dataset.id;
        if (target.classList.contains('btn-action-edit')) openModalForEdit(id);
        if (target.classList.contains('btn-action-delete')) deleteItem(id);
    }
    tableBody.addEventListener('click', handleActionClick);
    gridViewContainer.addEventListener('click', handleActionClick);
    gridViewBtn.addEventListener('click', () => {
        gridViewBtn.classList.add('active');
        tableViewBtn.classList.remove('active');
        gridViewContainer.style.display = 'grid';
        tableViewContainer.style.display = 'none';
    });
    tableViewBtn.addEventListener('click', () => {
        tableViewBtn.classList.add('active');
        gridViewBtn.classList.remove('active');
        tableViewContainer.style.display = 'block';
        gridViewContainer.style.display = 'none';
    });
    window.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Carga inicial de datos
    loadData();
}