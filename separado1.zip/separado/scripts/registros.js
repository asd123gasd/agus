// scripts/registros.js (Versión con Ruta de Importación Corregida)
import { db } from './firebase-config.js'; // <-- RUTA CORREGIDA
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { 
    collection, 
    query, 
    where, 
    orderBy, 
    getDocs,
    limit, 
    startAfter,
    endBefore
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', () => {
    const auth = getAuth();

    // --- Selectores de elementos ---
    const tbody = document.getElementById('tabla-remitos-body');
    if (!tbody) return;
    const tableContainer = document.querySelector('.table-container');

    // --- Variables de estado ---
    let currentUser = null;

    // ----- LÓGICA DE AUTENTICACIÓN -----
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            tableContainer.style.display = 'block';
            buildBaseQuery(); // Llama a la lógica principal de la página
        } else {
            // Si no hay usuario, lo redirigimos a la página de login
            window.location.href = 'auth/login.html';
        }
    });

    // El resto de tu código de registros.js (buildBaseQuery, loadPage, renderTable, y los event listeners)
    // debe permanecer aquí sin cambios. Te lo pego completo por si acaso.

    let currentPageData = [];
    let currentFilter = 'Todos';
    let currentVerArchivados = false;
    let baseQuery;
    
    const PAGE_SIZE = 15;
    let currentPage = 1;
    let lastVisibleDoc = null;
    let firstVisibleDoc = null;
    let pageSnapshots = {};

    const searchInput = document.getElementById('searchInput');
    const historialTitle = document.getElementById('historial-title');
    const filterButtonsContainer = document.getElementById('filter-buttons-container');
    const paginationContainer = document.getElementById('pagination-container');
    const prevPageBtn = document.getElementById('prevPageBtn');
    const nextPageBtn = document.getElementById('nextPageBtn');
    const pageInfo = document.getElementById('page-info');
    const verArchivadosSwitch = document.getElementById('verArchivadosSwitch');

      

    async function loadPage(direction) {
        if (!baseQuery) return;
        tbody.innerHTML = '<tr><td colspan="6" class="loading-row">Cargando...</td></tr>';
        
        let pageQuery;
        
        if (direction === 'next' && lastVisibleDoc) {
            pageQuery = query(baseQuery, startAfter(lastVisibleDoc), limit(PAGE_SIZE));
        } else if (direction === 'prev' && currentPage > 1) {
            const prevPageStartDoc = pageSnapshots[currentPage - 1];
            pageQuery = query(baseQuery, endBefore(prevPageStartDoc), limit(PAGE_SIZE));
        } else {
            pageQuery = query(baseQuery, limit(PAGE_SIZE));
        }
        
        try {
            const documentSnapshots = await getDocs(pageQuery);
            if (!documentSnapshots.empty) {
                firstVisibleDoc = documentSnapshots.docs[0];
                lastVisibleDoc = documentSnapshots.docs[documentSnapshots.docs.length - 1];
                
                if (direction === 'next') currentPage++;
                if (direction === 'prev') currentPage--;

                pageSnapshots[currentPage] = firstVisibleDoc;

                currentPageData = documentSnapshots.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                renderTable(currentPageData);
            } else if (direction === 'next') {
                // No hay más páginas
            } else {
                 currentPageData = [];
                 renderTable([]);
            }
            updatePaginationControls(documentSnapshots.size);
        } catch (error) {
            console.error("Error al cargar la página de remitos:", error);
            tbody.innerHTML = `<tr><td colspan="6">Error al cargar los datos.</td></tr>`;
        }
    }

    function resetAndLoadFirstPage() {
        currentPage = 1;
        lastVisibleDoc = null;
        firstVisibleDoc = null;
        pageSnapshots = {};
        loadPage('first');
    }
    
    function updatePaginationControls(currentSize) {
        pageInfo.textContent = `Página ${currentPage}`;
        prevPageBtn.disabled = currentPage === 1;
        nextPageBtn.disabled = currentSize < PAGE_SIZE;
        paginationContainer.style.display = (currentPage > 1 || currentSize >= PAGE_SIZE) ? 'flex' : 'none';
    }

    function renderTable(dataToRender) {
        tbody.innerHTML = '';
        if (dataToRender.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No se encontraron registros.</td></tr>';
            return;
        }
        dataToRender.forEach(remito => {
            const fecha = remito.fechaCreacion ? remito.fechaCreacion.toDate().toLocaleDateString('es-AR') : 'N/A';
            const estadoBadge = `<span class="status-badge" data-estado="${remito.estadoReparacion || 'Recibido'}">${remito.estadoReparacion || 'Recibido'}</span>`;
            const fila = `<tr><td>${fecha}</td><td>${remito.numeroRemito || 'N/A'}</td><td>${remito.clienteNombre || ''}</td><td>${remito.equipoMarca || ''} ${remito.equipoModelo || ''}</td><td>${estadoBadge}</td><td><a href="detalles-remito.html?id=${remito.id}" class="btn-ver-detalles">Ver</a></td></tr>`;
            tbody.innerHTML += fila;
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase().trim();
            if (!searchTerm) {
                renderTable(currentPageData);
                return;
            }
            const filteredResults = currentPageData.filter(r => 
                (r.clienteNombre || '').toLowerCase().includes(searchTerm) || 
                (String(r.numeroRemito) || '').toLowerCase().includes(searchTerm) ||
                (r.equipoMarca || '').toLowerCase().includes(searchTerm) || 
                (r.equipoModelo || '').toLowerCase().includes(searchTerm)
            );
            renderTable(filteredResults);
        });
    }
    
    if (filterButtonsContainer) {
        filterButtonsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('filter-btn')) {
                filterButtonsContainer.querySelector('.active').classList.remove('active');
                e.target.classList.add('active');
                currentFilter = e.target.dataset.filter;
                buildBaseQuery();
            }
        });
    }

    if (verArchivadosSwitch) {
        verArchivadosSwitch.addEventListener('change', () => {
            currentVerArchivados = verArchivadosSwitch.checked;
            historialTitle.textContent = currentVerArchivados ? 'Remitos Archivados' : 'Historial de Remitos';
            filterButtonsContainer.style.display = currentVerArchivados ? 'none' : 'flex';
            currentFilter = 'Todos';
            if (filterButtonsContainer.querySelector('.active')) {
                filterButtonsContainer.querySelector('.active').classList.remove('active');
                filterButtonsContainer.querySelector('[data-filter="Todos"]').classList.add('active');
            }
            buildBaseQuery();
        });
    }

    if (prevPageBtn) prevPageBtn.addEventListener('click', () => loadPage('prev'));
    if (nextPageBtn) nextPageBtn.addEventListener('click', () => loadPage('next'));
});