// scripts/firebase-config.js (Versión Final con Inicialización y Exportación)

// 1. Importar las funciones necesarias de Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// 2. Tu objeto de configuración (tus "llaves")
// (Asegúrate de que estas claves coincidan con las de tu proyecto en la consola de Firebase)
export const firebaseConfig = {
    apiKey: "AIzaSyCmfVkoylPskZBAgNDkLKaxLodc5ygoWTs",
    authDomain: "servicio-tecnico-pa-store.firebaseapp.com",
    projectId: "servicio-tecnico-pa-store",
    storageBucket: "servicio-tecnico-pa-store.appspot.com", // Corregido .appspot.com
    messagingSenderId: "54659231811",
    appId: "1:54659231811:web:ab434cc35e9ebce8b0a4f6",
    measurementId: "G-C7Q3B2QVK1"
};

// 3. Inicializar la aplicación de Firebase
const app = initializeApp(firebaseConfig);

// 4. Inicializar Cloud Firestore y obtener una referencia a la base de datos
const db = getFirestore(app);

// 5. ¡Línea Clave! Exportar la conexión a la base de datos para que otros archivos puedan usarla
export { db };