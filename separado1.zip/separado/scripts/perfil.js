// scripts/perfil.js (Versión Definitivamente Completa y Corregida)
import { db } from './firebase-config.js'; // <-- ESTA ES LA LÍNEA CORREGIDA
import { checkAuthStatus } from './auth/session.js';
import { doc, updateDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { getStorage, ref, uploadString, getDownloadURL } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-storage.js";

async function initializeProfilePage() {
    // 1. OBTENEMOS LOS DATOS MÁS RECIENTES DE LA NUBE
    const session = await checkAuthStatus();
    if (!session.isLoggedIn) {
        window.location.href = '../auth/login.html';
        return;
    }
    const currentUser = session.user;
    let tallerData = session.tallerData || {};
    const storage = getStorage();

    // --- SELECTORES DE ELEMENTOS (COMPLETOS) ---
    const saveProfileBtn = document.getElementById('saveProfileBtn');
    const statusMessage = document.getElementById('profile-status-message');
    const card = document.querySelector('.card-uiverse .card');
    const usernameDisplay = document.getElementById('displayUsername');
    const emailDisplay = document.getElementById('displayEmail');
    const phoneDisplay = document.getElementById('displayPhone');
    const instagramLink = document.getElementById('instagramLink');
    const twitterLink = document.getElementById('twitterLink');
    const whatsappLink = document.getElementById('whatsappLink');
    const facebookLink = document.getElementById('facebookLink');
    const usernameInput = document.getElementById('username-input');
    const emailInput = document.getElementById('email-input');
    const phoneInput = document.getElementById('phone-input');
    const instagramInput = document.getElementById('instagram-input');
    const twitterInput = document.getElementById('twitter-input');
    const whatsappInput = document.getElementById('whatsapp-input');
    const facebookInput = document.getElementById('facebook-input');
    const profilePictureInput = document.getElementById('profile-picture-input-display');
    const profilePicturePreview = document.getElementById('profilePicturePreviewDisplay');
    const logoFileInput = document.getElementById('logo-file-input');
    const logoPreviewImage = document.getElementById('logo-preview-image');
    const adFileInput = document.getElementById('ad-file-input');
    const adPreviewImage = document.getElementById('ad-preview-image');
    const cropModal = document.getElementById('cropModal');
    const imageToCrop = document.getElementById('imageToCrop');
    const cropButton = document.getElementById('cropButton');
    const cancelCropButton = document.getElementById('cancelCropButton');
    let cropper;
    const whatsappMessageTextareas = document.querySelectorAll('.chat-messages-config-section textarea');

    // --- LÓGICA DE LA INTERFAZ ORIGINAL ---
    if(card) {
        card.addEventListener('click', () => {
            card.classList.toggle('is-flipped');
        });
    }

    // --- FUNCIÓN PARA CARGAR Y MOSTRAR TODOS LOS DATOS DESDE FIRESTORE ---
    function populateUI() {
        usernameInput.value = tallerData.nombreTaller || '';
        emailInput.value = tallerData.email || '';
        emailInput.disabled = true;
        phoneInput.value = tallerData.telefono || '';
        instagramInput.value = tallerData.instagramURL || '';
        twitterInput.value = tallerData.twitterURL || '';
        whatsappInput.value = tallerData.whatsappURL || '';
        facebookInput.value = tallerData.facebookURL || '';
        displayUsername.textContent = tallerData.nombreTaller || 'Nombre de Taller';
        displayEmail.textContent = tallerData.email || 'tu@correo.com';
        displayPhone.textContent = tallerData.telefono || 'Tu Teléfono';
        instagramLink.href = tallerData.instagramURL || '#';
        twitterLink.href = tallerData.twitterURL || '#';
        whatsappLink.href = tallerData.whatsappURL || '#';
        facebookLink.href = tallerData.facebookURL || '#';
        const savedTemplates = tallerData.whatsappTemplates || {};
        whatsappMessageTextareas.forEach(textarea => {
            if (savedTemplates[textarea.id]) {
                textarea.value = savedTemplates[textarea.id];
            }
        });
        profilePicturePreview.src = tallerData.profilePictureUrl || 'https://placehold.co/100x100/334155/94A3B8?text=%2B';
        if (tallerData.logoUrl) {
            logoPreviewImage.src = tallerData.logoUrl;
            logoPreviewImage.closest('.upload-preview').style.display = 'block';
            logoPreviewImage.closest('.upload-area').querySelector('.upload-idle').style.display = 'none';
            document.getElementById('delete-logo-btn').style.display = 'inline-flex';
        }
        if (tallerData.adUrl) {
            adPreviewImage.src = tallerData.adUrl;
            adPreviewImage.closest('.upload-preview').style.display = 'block';
            adPreviewImage.closest('.upload-area').querySelector('.upload-idle').style.display = 'none';
            document.getElementById('delete-ad-btn').style.display = 'inline-flex';
        }
    }
    
    // --- LÓGICA DE GUARDADO COMPLETA ---
    if (saveProfileBtn) {
        saveProfileBtn.addEventListener('click', async () => {
            if (!currentUser) return;
            const whatsappTemplates = {};
            whatsappMessageTextareas.forEach(textarea => {
                whatsappTemplates[textarea.id] = textarea.value.trim();
            });
            const updatedProfileData = {
                nombreTaller: usernameInput.value.trim(),
                telefono: phoneInput.value.trim(),
                instagramURL: instagramInput.value.trim(),
                twitterURL: twitterInput.value.trim(),
                whatsappURL: whatsappInput.value.trim(),
                facebookURL: facebookInput.value.trim(),
                whatsappTemplates: whatsappTemplates
            };
            try {
                statusMessage.textContent = 'Guardando datos...';
                statusMessage.className = 'status-message';
                const tallerDocRef = doc(db, "talleres", currentUser.uid);
                await updateDoc(tallerDocRef, updatedProfileData);
                alert("¡Perfil guardado con éxito! La página se recargará para reflejar los cambios.");
                window.location.reload();
            } catch (error) {
                console.error("Error al actualizar el perfil: ", error);
                statusMessage.textContent = 'Error al guardar los cambios.';
                statusMessage.className = 'status-message error';
            }
        });
    }

    // --- LÓGICA DE SUBIDA DE IMÁGENES COMPLETA ---
    async function uploadImageAndUpdate(base64Data, path, field) {
        if (!currentUser) return;
        const storageRef = ref(storage, `${path}/${currentUser.uid}`);
        statusMessage.textContent = 'Subiendo imagen...';
        statusMessage.className = 'status-message info';
        try {
            await uploadString(storageRef, base64Data, 'data_url');
            const downloadURL = await getDownloadURL(storageRef);
            const tallerDocRef = doc(db, "talleres", currentUser.uid);
            await updateDoc(tallerDocRef, { [field]: downloadURL });
            tallerData[field] = downloadURL;
            populateUI();
            statusMessage.textContent = '¡Imagen actualizada!';
            statusMessage.className = 'status-message success';
            setTimeout(() => statusMessage.textContent = '', 3000);
        } catch (error) {
            console.error("Error al subir imagen: ", error);
            statusMessage.textContent = 'Error al subir la imagen.';
            statusMessage.className = 'status-message error';
        }
    }

    if (logoFileInput) {
        logoFileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if(file) {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => uploadImageAndUpdate(reader.result, 'logos', 'logoUrl');
            }
        });
    }

    if (adFileInput) {
        adFileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if(file) {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => uploadImageAndUpdate(reader.result, 'ads', 'adUrl');
            }
        });
    }

    if (profilePictureInput) {
        profilePictureInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = () => {
                    imageToCrop.src = reader.result;
                    if(cropModal) cropModal.style.display = 'flex';
                    if (cropper) cropper.destroy();
                    cropper = new Cropper(imageToCrop, { aspectRatio: 1, viewMode: 1 });
                };
                reader.readAsDataURL(file);
                e.target.value = '';
            }
        });
    }

    if (cropButton) {
        cropButton.addEventListener('click', async () => {
            if (cropper) {
                const croppedImageData = cropper.getCroppedCanvas({ width: 250, height: 250 }).toDataURL('image/jpeg');
                await uploadImageAndUpdate(croppedImageData, 'profile_pictures', 'profilePictureUrl');
                closeCropModal();
            }
        });
    }
    const closeCropModal = () => {
        if (cropModal) cropModal.style.display = 'none';
        if (cropper) cropper.destroy();
    };
    if (cancelCropButton) cancelCropButton.addEventListener('click', closeCropModal);

    // --- EJECUCIÓN INICIAL ---
    populateUI();
}

document.addEventListener('DOMContentLoaded', initializeProfilePage);