// scripts/proveedores.js
import { db } from './firebase-config.js';
import { checkAuthStatus } from './auth/session.js';
import {
    collection, query, where, orderBy, getDocs, doc, addDoc, updateDoc, deleteDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', async () => {
    const mainContainer = document.querySelector('.table-container');
    const session = await checkAuthStatus();

    if (!session.isLoggedIn) {
        window.location.href = '../auth/login.html';
        return;
    }
    
    // Asumimos que esta es una función para todos los usuarios, no hay muro premium.
    mainContainer.style.display = 'block';
    runSuppliersLogic(session.user);
});

function runSuppliersLogic(currentUser) {
    const tableBody = document.getElementById('suppliers-table-body');
    const loader = document.getElementById('loader');
    const openModalBtn = document.getElementById('btn-open-modal');
    const searchInput = document.getElementById('searchInput');
    
    const modal = document.getElementById('supplier-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelModalBtn = document.getElementById('modal-cancel-btn');
    const saveModalBtn = document.getElementById('modal-save-btn');
    const supplierForm = document.getElementById('supplier-form');
    const modalTitle = document.getElementById('modal-title');
    const supplierIdInput = document.getElementById('supplier-id');

    let fullSuppliers = [];

    async function loadSuppliers() {
        if (!currentUser) return;
        loader.style.display = 'flex';
        tableBody.innerHTML = '';
        
        try {
            const q = query(collection(db, "proveedores"), where("tallerId", "==", currentUser.uid), orderBy("nombre"));
            const querySnapshot = await getDocs(q);
            fullSuppliers = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            renderTable();
        } catch (error) {
            console.error("Error cargando proveedores: ", error);
            tableBody.innerHTML = `<tr><td colspan="5">Error al cargar los proveedores.</td></tr>`;
        } finally {
            loader.style.display = 'none';
        }
    }

    function renderTable() {
        const searchTerm = searchInput.value.toLowerCase();
        const filteredItems = fullSuppliers.filter(item => {
            return item.nombre.toLowerCase().includes(searchTerm) || 
                   (item.contacto || '').toLowerCase().includes(searchTerm) ||
                   (item.email || '').toLowerCase().includes(searchTerm);
        });

        tableBody.innerHTML = '';
        if (filteredItems.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="5" style="text-align: center;">No se encontraron proveedores.</td></tr>`;
            return;
        }

        filteredItems.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.nombre}</td>
                <td>${item.contacto || 'N/A'}</td>
                <td>${item.telefono || 'N/A'}</td>
                <td>${item.email || 'N/A'}</td>
                <td class="action-buttons-cell">
                    <button class="btn-action-edit" data-id="${item.id}" title="Editar"><i class="fas fa-edit"></i></button>
                    <button class="btn-action-delete" data-id="${item.id}" title="Eliminar"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    async function saveSupplier(e) {
        e.preventDefault();
        if (!supplierForm.checkValidity()) {
            supplierForm.reportValidity();
            return;
        }
        setSaveButtonLoading(true);

        const supplierId = supplierIdInput.value;
        const supplierData = {
            nombre: document.getElementById('supplier-name').value.trim(),
            contacto: document.getElementById('supplier-contact').value.trim(),
            telefono: document.getElementById('supplier-phone').value.trim(),
            email: document.getElementById('supplier-email').value.trim(),
            notas: document.getElementById('supplier-notes').value.trim(),
            ultimaModificacion: serverTimestamp()
        };

        try {
            if (supplierId) {
                await updateDoc(doc(db, "proveedores", supplierId), supplierData);
            } else {
                supplierData.tallerId = currentUser.uid;
                supplierData.fechaCreacion = serverTimestamp();
                await addDoc(collection(db, "proveedores"), supplierData);
            }
            closeModal();
            loadSuppliers();
        } catch (error) {
            console.error("Error guardando el proveedor: ", error);
            alert("Ocurrió un error al guardar.");
        } finally {
            setSaveButtonLoading(false);
        }
    }

    async function deleteSupplier(supplierId) {
        if (!confirm("¿Estás seguro de que quieres eliminar este proveedor? Se eliminará permanentemente.")) return;
        try {
            await deleteDoc(doc(db, "proveedores", supplierId));
            loadSuppliers();
        } catch (error) {
            console.error("Error eliminando el proveedor: ", error);
            alert("Ocurrió un error al eliminar.");
        }
    }

    function openModalForNew() {
        modalTitle.textContent = "Agregar Nuevo Proveedor";
        supplierForm.reset();
        supplierIdInput.value = '';
        modal.classList.add('visible');
    }

    function openModalForEdit(supplierId) {
        const item = fullSuppliers.find(i => i.id === supplierId);
        if (!item) return;
        modalTitle.textContent = "Editar Proveedor";
        supplierForm.reset();
        supplierIdInput.value = item.id;
        document.getElementById('supplier-name').value = item.nombre;
        document.getElementById('supplier-contact').value = item.contacto || '';
        document.getElementById('supplier-phone').value = item.telefono || '';
        document.getElementById('supplier-email').value = item.email || '';
        document.getElementById('supplier-notes').value = item.notas || '';
        modal.classList.add('visible');
    }

    function closeModal() {
        modal.classList.remove('visible');
    }

    function setSaveButtonLoading(isLoading) {
        const spinner = saveModalBtn.querySelector('.spinner');
        saveModalBtn.disabled = isLoading;
        spinner.style.display = isLoading ? 'block' : 'none';
        saveModalBtn.querySelector('span').style.display = isLoading ? 'none' : 'inline';
    }

    // Event Listeners
    openModalBtn.addEventListener('click', openModalForNew);
    closeModalBtn.addEventListener('click', closeModal);
    cancelModalBtn.addEventListener('click', closeModal);
    supplierForm.addEventListener('submit', saveSupplier);
    searchInput.addEventListener('input', renderTable);

    tableBody.addEventListener('click', (e) => {
        const target = e.target.closest('button');
        if (!target) return;
        const id = target.dataset.id;
        if (target.classList.contains('btn-action-edit')) openModalForEdit(id);
        if (target.classList.contains('btn-action-delete')) deleteSupplier(id);
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    loadSuppliers();
}