document.addEventListener('DOMContentLoaded', () => {
    // --- LÓGICA DE CAMBIO DE PESTAÑAS ---
    const tallerTabsContainer = document.getElementById('taller-tabs-container');
    if (!tallerTabsContainer) return;

    const tabButtons = tallerTabsContainer.querySelectorAll('.tab-button');
    const tabPanelsContainer = tallerTabsContainer.querySelector('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabIdToShow = button.dataset.tab;
            
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            tabPanelsContainer.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
            
            const panelToShow = document.getElementById(tabIdToShow);
            if (panelToShow) {
                panelToShow.classList.add('active');
            }
        });
    });

    // --- LÓGICA PARA LOS UPLOADERS PROFESIONALES ---
    
    /**
     * Configura un componente de carga de archivos completo con Drag & Drop y previsualización.
     * @param {string} areaId - ID del área de "arrastrar y soltar".
     * @param {string} inputId - ID del input de tipo 'file'.
     * @param {string} previewImgId - ID de la imagen de previsualización.
     * @param {string} deleteBtnId - ID del botón para eliminar la imagen.
     */
    function setupUploader(areaId, inputId, previewImgId, deleteBtnId) {
        const uploadArea = document.getElementById(areaId);
        const fileInput = document.getElementById(inputId);
        const previewImage = document.getElementById(previewImgId);
        const deleteBtn = document.getElementById(deleteBtnId);

        if (!uploadArea || !fileInput || !previewImage || !deleteBtn) {
            console.warn(`Faltan elementos para el uploader: ${areaId}`);
            return;
        }

        const idleDiv = uploadArea.querySelector('.upload-idle');
        const previewDiv = uploadArea.querySelector('.upload-preview');

        // Función para manejar el archivo seleccionado (ya sea por clic o por drop)
        const handleFile = (file) => {
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    previewImage.src = e.target.result;
                    idleDiv.style.display = 'none';
                    previewDiv.style.display = 'block';
                    deleteBtn.style.display = 'inline-flex';
                };
                reader.readAsDataURL(file);
            } else {
                alert('Por favor, selecciona un archivo de imagen válido.');
            }
        };
        
        // Función para resetear el uploader a su estado inicial
        const resetUploader = () => {
            fileInput.value = ''; // Importante para poder seleccionar el mismo archivo de nuevo
            previewImage.src = '';
            idleDiv.style.display = 'flex';
            previewDiv.style.display = 'none';
            deleteBtn.style.display = 'none';
        };

        // --- Event Listeners ---

        // Abrir selector de archivos al hacer clic en el área
        uploadArea.addEventListener('click', () => fileInput.click());

        // Manejar archivo seleccionado por el input
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFile(e.target.files[0]);
            }
        });

        // Eventos de Drag & Drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragging');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragging');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragging');
            if (e.dataTransfer.files.length > 0) {
                fileInput.files = e.dataTransfer.files; // Asigna el archivo al input
                handleFile(e.dataTransfer.files[0]);
            }
        });
        
        // Botón de eliminar
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Evita que el clic se propague al 'uploadArea'
            resetUploader();
        });
    }

    // Inicializar los dos uploaders
    setupUploader('logo-upload-area', 'logo-file-input', 'logo-preview-image', 'delete-logo-btn');
    setupUploader('ad-upload-area', 'ad-file-input', 'ad-preview-image', 'delete-ad-btn');
});