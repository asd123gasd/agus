// scripts/detalles-remito.js (Versión Final, Completa y Corregida)
import { db } from './firebase-config.js';
import { checkAuthStatus } from './auth/session.js';
import {
    doc, getDoc, updateDoc, arrayUnion, serverTimestamp, runTransaction, collection, query, where, orderBy, getDocs
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', async () => {
    const session = await checkAuthStatus();
    if (!session.isLoggedIn) {
        window.location.href = 'auth/login.html';
        return;
    }
    const currentUser = session.user;

    // --- Selectores de Elementos ---
    const loader = document.getElementById('loader');
    const contentContainer = document.getElementById('content-container');
    const remitoTitle = document.getElementById('remito-title');
    const repuestosContainer = document.getElementById('repuestos-utilizados-container');
    const clienteNombre = document.getElementById('cliente-nombre');
    const clienteTelefono = document.getElementById('cliente-telefono');
    const clienteEmail = document.getElementById('cliente-email');
    const equipoTipo = document.getElementById('equipo-tipo');
    const equipoColor = document.getElementById('equipo-color');
    const equipoModelo = document.getElementById('equipo-modelo');
    const equipoSerie = document.getElementById('equipo-serie');
    const equipoClave = document.getElementById('equipo-clave');
    const fallaCategoria = document.getElementById('falla-categoria');
    const fallaDescripcion = document.getElementById('falla-descripcion');
    const estadoIngreso = document.getElementById('estado-ingreso');
    const accesoriosEntregados = document.getElementById('accesorios-entregados');
    const diagCarga = document.getElementById('diag-carga');
    const diagEnciende = document.getElementById('diag-enciende');
    const diagGolpeado = document.getElementById('diag-golpeado');
    const diagMojado = document.getElementById('diag-mojado');
    const estadoBadge = document.getElementById('estado-badge');
    const diagnosticoValor = document.getElementById('diagnostico-valor');
    const historialTimeline = document.getElementById('historial-timeline');
    const historialBadge = document.getElementById('historial-badge');
    const btnAsignarRepuestos = document.getElementById('label-asignar-repuestos');
    const btnNotificarWhatsApp = document.getElementById('label-notificar');
    const btnImprimir = document.getElementById('label-imprimir');
    const btnActualizarEstado = document.getElementById('label-actualizar');
    const btnArchivar = document.getElementById('btn-archivar');
    const modalRepuestos = document.getElementById('modal-asignar-repuestos');
    const closeModalRepuestosBtn = document.getElementById('modal-repuestos-close-btn');
    const cancelModalRepuestosBtn = document.getElementById('btn-cancelar-repuestos');
    const saveModalRepuestosBtn = document.getElementById('btn-guardar-repuestos');
    const searchRepuestosInput = document.getElementById('search-repuestos-input');
    const listaInventarioDisp = document.getElementById('lista-inventario-disponible');
    const listaRepuestosAsignados = document.getElementById('lista-repuestos-asignados');
    const modalActualizar = document.getElementById('modal-actualizar');
    const modalCloseBtn = document.getElementById('modal-close-btn');
    const btnCancelar = document.getElementById('btn-cancelar');
    const formActualizar = document.getElementById('form-actualizar');
    const editEstado = document.getElementById('edit-estado');
    const editDiagnostico = document.getElementById('edit-diagnostico');
    const editPresupuesto = document.getElementById('edit-presupuesto');
    const modalConfirmar = document.getElementById('modal-confirmar');
    const btnConfirmarAccion = document.getElementById('btn-confirmar-accion');
    const btnCancelarAccion = document.getElementById('btn-cancelar-accion');
    const modalConfirmarTexto = document.getElementById('modal-confirmar-texto');

    // Selectores del Nuevo Panel Financiero
    const summaryPresupuesto = document.getElementById('summary-presupuesto');
    const summaryCostoRepuestos = document.getElementById('summary-costo-repuestos');
    const summaryGanancia = document.getElementById('summary-ganancia');

    let currentRemitoId = null;
    let currentRemitoData = {};
    let fullInventory = [];
    let tempAssignedParts = [];

    const urlParams = new URLSearchParams(window.location.search);
    currentRemitoId = urlParams.get('id');
    if (!currentRemitoId) {
        remitoTitle.textContent = "Error: ID de remito no válido.";
        loader.style.display = 'none';
        contentContainer.style.visibility = 'visible';
        return;
    }
    const remitoDocRef = doc(db, "remitos", currentRemitoId);

    async function cargarDatosRemito() {
        try {
            const docSnap = await getDoc(remitoDocRef);
            if (docSnap.exists()) {
                currentRemitoData = { id: docSnap.id, ...docSnap.data() };
                renderizarDatosPrincipales(currentRemitoData);
                renderizarRepuestos(currentRemitoData);
                renderizarResumenFinanciero(currentRemitoData);
            } else { remitoTitle.textContent = "Error: Remito no encontrado."; }
        } catch (error) {
            console.error("Error al cargar el remito:", error);
            remitoTitle.textContent = "Error al cargar datos.";
        } finally {
            loader.style.display = 'none';
            contentContainer.style.visibility = 'visible';
        }
    }

    function renderizarDatosPrincipales(data) {
        const na = 'No especificado';
        remitoTitle.textContent = `Remito #${data.numeroRemito || 'N/A'}`;
        clienteNombre.textContent = data.clienteNombre || na;
        clienteTelefono.textContent = data.clienteTelefono || na;
        clienteEmail.textContent = data.clienteEmail || na;
        equipoTipo.textContent = data.equipoTipo || na;
        equipoColor.textContent = data.equipoColor || na;
        equipoModelo.textContent = `${data.equipoMarca || ''} ${data.equipoModelo || ''}`;
        equipoSerie.textContent = data.equipoSerie || na;
        equipoClave.textContent = data.claveContraseña || na;
        fallaCategoria.textContent = data.fallaCategoria || na;
        fallaDescripcion.textContent = data.descripcionFalla || na;
        estadoIngreso.textContent = data.estadoCelular || na;
        accesoriosEntregados.textContent = data.accesoriosEntregados?.join(', ') || 'Ninguno';
        diagCarga.textContent = data.diagnosticoCarga || na;
        diagEnciende.textContent = data.diagnosticoEnciende || na;
        diagGolpeado.textContent = data.diagnosticoGolpeado || na;
        diagMojado.textContent = data.diagnosticoMojado || na;
        const estadoActual = data.estadoReparacion || 'Recibido';
        estadoBadge.textContent = estadoActual;
        estadoBadge.setAttribute('data-estado', estadoActual);
        diagnosticoValor.textContent = data.diagnostico || 'Pendiente de revisión.';

        historialTimeline.innerHTML = '';
        const historial = data.historial || [];
        if (historial.length > 0) {
            historialBadge.textContent = `${historial.length} Cambios`;
            historialBadge.style.display = 'inline-block';
            [...historial].sort((a, b) => (b.fecha?.toMillis() || 0) - (a.fecha?.toMillis() || 0)).forEach(evento => {
                const item = document.createElement('div');
                item.className = 'timeline-item';
                item.innerHTML = `<div class="timeline-icon"><i class="fas fa-check"></i></div><div class="timeline-content"><span class="cambio">${evento.cambio}</span><span class="fecha">${evento.fecha?.toDate()?.toLocaleString('es-AR') || 'Fecha no disponible'}</span></div>`;
                historialTimeline.appendChild(item);
            });
        } else {
            historialBadge.style.display = 'none';
            historialTimeline.innerHTML = '<p>No hay historial de cambios.</p>';
        }

        const esEntregadoOArchivado = estadoActual === 'Entregado' || data.archivado;
        // La propiedad 'disabled' no funciona igual en labels, pero se puede manejar con CSS (pointer-events: none) si se necesita.
        // Por ahora, se deja la interacción y se controla la lógica en los eventos.
        btnArchivar.style.display = estadoActual === 'Entregado' && !data.archivado ? 'inline-flex' : 'none';
    }

    function renderizarRepuestos(data) {
        repuestosContainer.innerHTML = '';
        const repuestosUtilizados = data.repuestosUtilizados || [];

        if (repuestosUtilizados.length === 0) {
            repuestosContainer.innerHTML = '<p>No se han asignado repuestos a esta reparación.</p>';
            return;
        }
        let totalCosto = 0;
        const listaHTML = document.createElement('div');
        repuestosUtilizados.forEach(repuesto => {
            const costoItem = repuesto.cantidad * repuesto.precioCosto;
            totalCosto += costoItem;
            const itemDiv = document.createElement('div');
            itemDiv.className = 'repuesto-item';
            itemDiv.innerHTML = `
                <span class="repuesto-nombre"><span class="cantidad">${repuesto.cantidad}x</span> ${repuesto.nombre}</span>
                <span class="repuesto-costo">${new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(costoItem)}</span>
            `;
            listaHTML.appendChild(itemDiv);
        });
        repuestosContainer.appendChild(listaHTML);
    }

    function renderizarResumenFinanciero(data) {
        const presupuesto = data.presupuesto || 0;
        const repuestosUtilizados = data.repuestosUtilizados || [];
        const costoRepuestos = repuestosUtilizados.reduce((total, repuesto) => {
            return total + (repuesto.cantidad * repuesto.precioCosto);
        }, 0);
        const gananciaEstimada = presupuesto - costoRepuestos;
        const formatCurrency = (value) => new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(value);

        summaryPresupuesto.textContent = formatCurrency(presupuesto);
        summaryCostoRepuestos.textContent = formatCurrency(costoRepuestos);
        summaryGanancia.textContent = formatCurrency(gananciaEstimada);

        summaryGanancia.classList.remove('ganancia-positiva', 'ganancia-negativa');
        if (gananciaEstimada >= 0) {
            summaryGanancia.classList.add('ganancia-positiva');
        } else {
            summaryGanancia.classList.add('ganancia-negativa');
        }
    }

    async function openAssignPartsModal() {
        if (fullInventory.length === 0) {
            try {
                const invQuery = query(collection(db, "inventario"), where("tallerId", "==", currentUser.uid), orderBy("nombre"));
                const querySnapshot = await getDocs(invQuery);
                fullInventory = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            } catch (error) {
                console.error("Error al cargar inventario:", error);
                alert("No se pudo cargar el inventario.");
                return;
            }
        }
        tempAssignedParts = JSON.parse(JSON.stringify(currentRemitoData.repuestosUtilizados || []));
        renderAvailableInventory();
        renderAssignedParts();
        modalRepuestos.style.display = 'flex';
    }

    function renderAvailableInventory() {
        listaInventarioDisp.innerHTML = '';
        const searchTerm = searchRepuestosInput.value.toLowerCase();
        fullInventory
            .filter(item => item.nombre.toLowerCase().includes(searchTerm) || (item.sku || '').toLowerCase().includes(searchTerm))
            .forEach(item => {
                const div = document.createElement('div');
                div.className = 'item-disponible';
                div.innerHTML = `
                    <div class="item-info">
                        <span class="nombre">${item.nombre}</span>
                        <span class="stock">Stock: ${item.stock}</span>
                    </div>
                    <div class="item-disponible-actions">
                        <button class="btn-add-repuesto" data-id="${item.id}" title="Agregar">+</button>
                    </div>
                `;
                listaInventarioDisp.appendChild(div);
            });
    }

    function renderAssignedParts() {
        listaRepuestosAsignados.innerHTML = '';
        if (tempAssignedParts.length === 0) {
            listaRepuestosAsignados.innerHTML = '<p>Aún no has asignado repuestos.</p>';
            return;
        }
        tempAssignedParts.forEach(part => {
            const div = document.createElement('div');
            div.className = 'item-asignado';
            div.innerHTML = `
                <span class="item-info">${part.nombre}</span>
                <div class="item-asignado-actions">
                    <input type="number" class="cantidad-input" data-id="${part.id}" value="${part.cantidad}" min="1">
                    <button class="btn-remove-repuesto" data-id="${part.id}" title="Quitar">&times;</button>
                </div>
            `;
            listaRepuestosAsignados.appendChild(div);
        });
    }

    async function saveAssignedParts() {
        saveModalRepuestosBtn.disabled = true;
        const oldParts = currentRemitoData.repuestosUtilizados || [];
        const newParts = tempAssignedParts;
        try {
            await runTransaction(db, async (transaction) => {
                const stockUpdates = new Map();
                const oldPartsMap = new Map(oldParts.map(p => [p.id, p.cantidad]));
                const newPartsMap = new Map(newParts.map(p => [p.id, p.cantidad]));
                for (const part of newParts) {
                    const oldQty = oldPartsMap.get(part.id) || 0;
                    const diff = part.cantidad - oldQty;
                    if (diff > 0) stockUpdates.set(part.id, (stockUpdates.get(part.id) || 0) - diff);
                }
                for (const part of oldParts) {
                    const newQty = newPartsMap.get(part.id) || 0;
                    const diff = part.cantidad - newQty;
                    if (diff > 0) stockUpdates.set(part.id, (stockUpdates.get(part.id) || 0) + diff);
                }
                for (const [itemId, qtyChange] of stockUpdates.entries()) {
                    if (qtyChange < 0) {
                        const itemRef = doc(db, "inventario", itemId);
                        const itemDoc = await transaction.get(itemRef);
                        if (!itemDoc.exists() || itemDoc.data().stock < Math.abs(qtyChange)) {
                            throw new Error(`Stock insuficiente para: ${itemDoc.data().nombre}.`);
                        }
                    }
                }
                for (const [itemId, qtyChange] of stockUpdates.entries()) {
                    const itemRef = doc(db, "inventario", itemId);
                    const itemDoc = await transaction.get(itemRef);
                    const newStock = itemDoc.data().stock + qtyChange;
                    transaction.update(itemRef, { stock: newStock });
                }
                transaction.update(remitoDocRef, { repuestosUtilizados: newParts });
            });
            closeAssignPartsModal();
            await cargarDatosRemito();
        } catch (error) {
            console.error("Error al guardar repuestos: ", error);
            alert("Error: " + error.message);
        } finally {
            saveModalRepuestosBtn.disabled = false;
        }
    }

    function closeAssignPartsModal() {
        modalRepuestos.style.display = 'none';
        searchRepuestosInput.value = '';
    }

    // --- LÓGICA DEL ACORDEÓN CON SCROLL SUAVE (BLOQUE ACTUALIZADO) ---
    const accordionItems = document.querySelectorAll('.accordion-item');
    accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header');
        header.addEventListener('click', () => {
            const isActive = item.classList.contains('active');

            // Cierra los otros acordeones antes de abrir uno nuevo
            accordionItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                    otherItem.querySelector('.accordion-content').style.maxHeight = null;
                }
            });

            // Abre o cierra el item clickeado
            if (isActive) {
                item.classList.remove('active');
                item.querySelector('.accordion-content').style.maxHeight = null;
            } else {
                item.classList.add('active');
                const content = item.querySelector('.accordion-content');
                content.style.maxHeight = content.scrollHeight + "px";

                // Lógica de Scroll Suave
                setTimeout(() => {
                    item.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start' // <-- CAMBIO CLAVE: Usa 'start' en lugar de 'nearest'
                    });
                }, 300);
            }
        });
    });

    if (btnImprimir) {
        btnImprimir.addEventListener('click', () => {
            window.open(`imprimir.html?id=${currentRemitoId}`, '_blank');
        });
    }

    function abrirModalActualizar() {
        if (!modalActualizar) return;
        editEstado.value = currentRemitoData.estadoReparacion || 'Recibido';
        editDiagnostico.value = currentRemitoData.diagnostico || '';
        editPresupuesto.value = currentRemitoData.presupuesto || '';
        modalActualizar.style.display = "block";
    }
    function cerrarModalActualizar() { if (modalActualizar) modalActualizar.style.display = "none"; }
    function cerrarModalConfirmacion() { if (modalConfirmar) modalConfirmar.style.display = "none"; }

    if (btnActualizarEstado) btnActualizarEstado.addEventListener('click', abrirModalActualizar);
    if (modalCloseBtn) modalCloseBtn.addEventListener('click', cerrarModalActualizar);
    if (btnCancelar) btnCancelar.addEventListener('click', cerrarModalActualizar);
    if (btnCancelarAccion) btnCancelarAccion.addEventListener('click', cerrarModalConfirmacion);

    if (formActualizar) {
        formActualizar.addEventListener('submit', (e) => {
            e.preventDefault();
            const textoConfirmacion = `¿Estás seguro de que deseas guardar estos cambios en el remito?`;
            abrirModalConfirmacion('guardar', textoConfirmacion);
        });
    }

    if (btnArchivar) {
        btnArchivar.addEventListener('click', () => {
            abrirModalConfirmacion('archivar', `Estás a punto de <strong>ARCHIVAR</strong> este remito. No aparecerá en la lista principal. ¿Estás seguro?`);
        });
    }

    function abrirModalConfirmacion(accion, texto) {
        if (!modalConfirmar) return;
        modalConfirmarTexto.innerHTML = texto;
        btnConfirmarAccion.dataset.accion = accion;
        btnConfirmarAccion.className = accion === 'archivar' ? 'action-btn danger' : 'action-btn primary';
        modalConfirmar.style.display = 'block';
    }

    if (btnConfirmarAccion) {
        btnConfirmarAccion.addEventListener('click', async () => {
            const accion = btnConfirmarAccion.dataset.accion;
            try {
                if (accion === 'guardar') {
                    const nuevoEstado = editEstado.value;
                    const updatedData = {
                        estadoReparacion: nuevoEstado,
                        diagnostico: editDiagnostico.value,
                        presupuesto: parseFloat(editPresupuesto.value) || 0
                    };
                    if (currentRemitoData.estadoReparacion !== nuevoEstado) {
                        updatedData.historial = arrayUnion({ cambio: `Estado actualizado a "${nuevoEstado}".`, fecha: new Date() });
                    }
                    await updateDoc(remitoDocRef, updatedData);
                    cerrarModalActualizar();
                } else if (accion === 'archivar') {
                    await updateDoc(remitoDocRef, {
                        archivado: true,
                        historial: arrayUnion({ cambio: `El remito fue archivado.`, fecha: new Date() })
                    });
                    window.location.href = 'registros.html';
                }
                cerrarModalConfirmacion();
                cargarDatosRemito();
            } catch (error) {
                console.error("Error en la acción:", error);
                alert("Ocurrió un error al procesar la acción.");
            }
        });
    }

    if(btnNotificarWhatsApp){
        btnNotificarWhatsApp.addEventListener('click', async () => {
             const session = await checkAuthStatus();
             if (!session.isLoggedIn || !session.tallerData) return;
             const estadoActual = currentRemitoData.estadoReparacion;
             const mensaje = generarMensajeWhatsApp(estadoActual, currentRemitoData, session.tallerData);
             if (mensaje) {
                 const telefonoLimpio = currentRemitoData.clienteTelefono.replace(/[\s\-\+()]/g, '');
                 const urlWhatsApp = `https://api.whatsapp.com/send?phone=${telefonoLimpio}&text=${encodeURIComponent(mensaje)}`;
                 window.open(urlWhatsApp, '_blank');
             } else {
                 alert(`No hay plantilla configurada para el estado "${estadoActual}".`);
             }
        });
    }

    function generarMensajeWhatsApp(estado, datosRemito, tallerData) {
        const customTemplates = tallerData.whatsappTemplates || {};
        const nombreTaller = tallerData.nombreTaller || 'Tu Taller';
        const keyMap = {
            'Recibido': 'whatsapp-status-recibido-message', 'En revisión': 'whatsapp-status-revision-message', 'Esperando repuesto': 'whatsapp-status-esperando-repuesto-message',
            'Esperando aprobación': 'whatsapp-status-esperando-aprobacion-message', 'Reparado': 'whatsapp-status-reparado-message', 'Listo para retirar': 'whatsapp-status-listo-retirar-message',
            'Entregado': 'whatsapp-status-entregado-message', 'Sin reparación': 'whatsapp-status-sin-reparacion-message'
        };
        const templateKey = keyMap[estado];
        if (!templateKey) return null;
        let template = customTemplates[templateKey] || customTemplates['whatsapp-status-update-general-message'] || '';
        if (!template) return `Hola ${datosRemito.clienteNombre.split(' ')[0]}, te informamos que el estado de tu equipo (Orden #${datosRemito.numeroRemito}) ha sido actualizado a: ${estado}. Atentamente, ${nombreTaller}.`;
        const replacements = {
            '{nombre_cliente}': datosRemito.clienteNombre.split(' ')[0], '{remito_numero}': datosRemito.numeroRemito,
            '{nombre_taller}': nombreTaller, '{nuevo_estado}': estado
        };
        for (const placeholder in replacements) {
            template = template.replace(new RegExp(placeholder.replace(/\{|\}/g, '\\$&'), 'g'), replacements[placeholder]);
        }
        return template.trim();
    }

    if (btnAsignarRepuestos) btnAsignarRepuestos.addEventListener('click', openAssignPartsModal);
    if (closeModalRepuestosBtn) closeModalRepuestosBtn.addEventListener('click', closeAssignPartsModal);
    if (cancelModalRepuestosBtn) cancelModalRepuestosBtn.addEventListener('click', closeAssignPartsModal);
    if (saveModalRepuestosBtn) saveModalRepuestosBtn.addEventListener('click', saveAssignedParts);
    if (searchRepuestosInput) searchRepuestosInput.addEventListener('input', renderAvailableInventory);

    if (listaInventarioDisp) {
        listaInventarioDisp.addEventListener('click', e => {
            if (e.target.classList.contains('btn-add-repuesto')) {
                const itemId = e.target.dataset.id;
                const existingPart = tempAssignedParts.find(p => p.id === itemId);
                if (existingPart) {
                    existingPart.cantidad++;
                } else {
                    const item = fullInventory.find(i => i.id === itemId);
                    tempAssignedParts.push({ id: item.id, nombre: item.nombre, precioCosto: item.precioCosto, cantidad: 1 });
                }
                renderAssignedParts();
            }
        });
    }

    if (listaRepuestosAsignados) {
        listaRepuestosAsignados.addEventListener('click', e => {
            const target = e.target;
            if (target.classList.contains('btn-remove-repuesto')) {
                tempAssignedParts = tempAssignedParts.filter(p => p.id !== target.dataset.id);
                renderAssignedParts();
            }
        });

        listaRepuestosAsignados.addEventListener('change', e => {
            const target = e.target;
            if (target.classList.contains('cantidad-input')) {
                const part = tempAssignedParts.find(p => p.id === target.dataset.id);
                if (part) {
                    const newQty = parseInt(target.value);
                    if (newQty > 0) part.cantidad = newQty;
                    else target.value = part.cantidad;
                }
            }
        });
    }

    cargarDatosRemito();
});