// scripts/main.js (Versión Final con Autorrelleno y Lógica de Logout)
import { db } from './firebase-config.js';
import { getAuth, signOut } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { checkAuthStatus } from './auth/session.js';

document.addEventListener('DOMContentLoaded', async () => {
    const body = document.body;

    const session = await checkAuthStatus();

    if (!session.isLoggedIn && !window.location.pathname.includes('/auth/')) {
        window.location.href = 'auth/login.html'; // Corregido para ir desde la raíz
        return;
    }

    if (session.isLoggedIn && session.tallerData) {
        const usernameDisplayTop = document.getElementById('username-display-top');
        const usernameDisplay = document.getElementById('username-display');
        const profilePicturePreviewTop = document.getElementById('profilePicturePreviewTop');

        if (usernameDisplayTop) {
            usernameDisplayTop.textContent = session.tallerData.nombreTaller || 'Sin Nombre';
        }
        if (usernameDisplay) {
            usernameDisplay.textContent = session.tallerData.nombreTaller || 'Usuario';
        }
        if (profilePicturePreviewTop && session.tallerData.profilePictureUrl) {
            profilePicturePreviewTop.src = session.tallerData.profilePictureUrl;
        }
    }

    const header = document.querySelector('header');
    if (header && !body.classList.contains('no-sidebar-expand')) {
        header.addEventListener('mouseenter', () => {
            if (window.innerWidth > 820) {
                header.classList.add('expanded');
                body.classList.add('sidebar-expanded');
            }
        });
        header.addEventListener('mouseleave', () => {
            if (window.innerWidth > 820) {
                header.classList.remove('expanded');
                body.classList.remove('sidebar-expanded');
            }
        });
    }

    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('change', () => {
            body.classList.toggle('dark-mode', darkModeToggle.checked);
            body.classList.toggle('light-mode', !darkModeToggle.checked);
        });
        if (body.classList.contains('dark-mode')) {
            darkModeToggle.checked = true;
        }
    }

    const profileSection = document.querySelector('.profile-section-top');
    if (profileSection) {
        profileSection.style.cursor = 'pointer';
        profileSection.addEventListener('click', async () => {
            if (confirm("¿Estás seguro de que quieres cerrar la sesión?")) {
                const auth = getAuth();
                try {
                    await signOut(auth);
                    window.location.href = 'auth/login.html'; // Corregido para ir desde la raíz
                } catch (error) {
                    console.error("Error al cerrar sesión:", error);
                }
            }
        });
    }
});