// scripts/confirmacion.js (COMPLETO Y CORREGIDO)
import { db } from './firebase-config.js';
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { checkAuthStatus } from './auth/session.js';

document.addEventListener('DOMContentLoaded', () => {
    const loader = document.getElementById('loader');
    const content = document.getElementById('confirmation-content');

    // ===== INICIO DE LA MODIFICACIÓN =====
    // Leemos todos los parámetros necesarios de la URL
    const urlParams = new URLSearchParams(window.location.search);
    const docId = urlParams.get('docId');
    const remitoNo = urlParams.get('remitoNo');
    const cliente = decodeURIComponent(urlParams.get('cliente'));

    // Verificamos que tengamos la información mínima
    if (!docId || !remitoNo || !cliente) {
        content.innerHTML = '<h1>Error: Falta información para mostrar la confirmación.</h1><p>Por favor, regresa a registrar un nuevo equipo.</p>';
        loader.classList.add('hidden');
        content.classList.remove('hidden');
        return;
    }

    // Llenamos el contenido directamente desde la URL
    document.getElementById('remito-number').textContent = remitoNo;
    document.getElementById('client-name').textContent = cliente;

    // Los botones ahora usan el docId (ID completo) para sus funciones
    document.getElementById('btnImprimirA4').addEventListener('click', () => {
        window.open(`imprimir.html?id=${docId}`, '_blank');
    });
    document.getElementById('btnImprimirTicket').addEventListener('click', () => {
        window.open(`imprimir.html?id=${docId}`, '_blank');
    });

    document.getElementById('btnNotificar').addEventListener('click', async () => {
        try {
            // Se necesita hacer una consulta a la DB solo al notificar
            const docRef = doc(db, "remitos", docId);
            const docSnap = await getDoc(docRef);

            if (!docSnap.exists()) {
                alert("Error: No se encontró el remito para notificar.");
                return;
            }
            const data = docSnap.data();

            const session = await checkAuthStatus();
            if (!session.isLoggedIn) {
                alert('Error de autenticación. Por favor, recarga la página.');
                return;
            }
            const tallerData = session.tallerData;

            const { clienteNombre, clienteTelefono, equipoMarca, equipoModelo, descripcionFalla, numeroRemito } = data;
            let telefonoClienteLimpio = clienteTelefono.replace(/\D/g, '');
            
            const nombreTaller = tallerData.nombreTaller || 'Tu Servicio Técnico';
            const customTemplates = tallerData.whatsappTemplates || {};

            let mensajeTemplate = customTemplates['whatsapp-register-message'] || `Hola *{nombre_cliente}* 👋, confirmamos la recepción de tu equipo en *{nombre_taller}*.\n\n*N° de Orden:* {remito_numero}\n\n*Resumen del Ingreso:*\n- *Equipo:* {equipo_marca} {equipo_modelo}\n- *Falla Reportada:* {falla_reportada}\n\nGracias por confiar en nosotros.\nAtentamente,\n*El equipo de {nombre_taller}* 😊`;
            
            let mensajeFinal = mensajeTemplate
                .replace(/{nombre_cliente}/g, clienteNombre.split(' ')[0])
                .replace(/{nombre_taller}/g, nombreTaller)
                .replace(/{remito_numero}/g, numeroRemito)
                .replace(/{equipo_marca}/g, equipoMarca)
                .replace(/{equipo_modelo}/g, equipoModelo)
                .replace(/{falla_reportada}/g, descripcionFalla);

            if (telefonoClienteLimpio.length <= 10 && !telefonoClienteLimpio.startsWith('54')) { 
                telefonoClienteLimpio = '54' + telefonoClienteLimpio; 
            }
            const urlWhatsapp = `https://wa.me/${telefonoClienteLimpio}?text=${encodeURIComponent(mensajeFinal)}`;
            window.open(urlWhatsapp, '_blank');

        } catch (error) {
            console.error("Error al notificar por WhatsApp:", error);
            alert("No se pudo obtener la información del remito para notificar.");
        }
    });

    // Mostramos el contenido, ya que no hay que esperar a la base de datos
    loader.classList.add('hidden');
    content.classList.remove('hidden');
    // ===== FIN DE LA MODIFICACIÓN =====
});