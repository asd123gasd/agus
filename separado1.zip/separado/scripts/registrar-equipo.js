// scripts/registrar-equipo.js (COMPLETO Y CORREGIDO)
import { db } from './firebase-config.js';
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { collection, addDoc, updateDoc, serverTimestamp, arrayUnion } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', () => {
    const auth = getAuth();
    const form = document.getElementById('registroEquipos');
    if (!form) return;

    const generarRemitoBtn = document.getElementById('generarRemito');
    let currentUser = null;

    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            generarRemitoBtn.disabled = false;
        } else {
            currentUser = null;
            generarRemitoBtn.disabled = true;
            const btnSpan = generarRemitoBtn.querySelector('span');
            if (btnSpan) btnSpan.textContent = 'Inicia sesión para registrar';
        }
    });

    const steps = document.querySelectorAll('.form-step');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const progressSteps = document.querySelectorAll('.progress-step');
    const originalBtnGroup = document.querySelector('.btn-group');
    const navigationBtnGroup = document.querySelector('.navigation-btns');

    let currentStep = 1;
    const totalSteps = steps.length;

    const validateCurrentStep = () => {
        const activeStep = document.querySelector(`.form-step[data-step="${currentStep}"]`);
        if (!activeStep) return false;

        const requiredInputsInStep = activeStep.querySelectorAll('input[required], textarea[required], select[required]');
        for (const input of requiredInputsInStep) {
            if (input.type === 'checkbox') {
                if (!input.checked) {
                    Toastify({ text: "Debe aceptar los términos para continuar.", duration: 3000, gravity: "top", position: "right", style: { background: "linear-gradient(to right, #dc3545, #c31432)" } }).showToast();
                    return false;
                }
            } else if (!input.value.trim()) {
                Toastify({ text: "Por favor, complete todos los campos requeridos (*)", duration: 3000, gravity: "top", position: "right", style: { background: "linear-gradient(to right, #dc3545, #c31432)" } }).showToast();
                return false;
            }
        }
        return true;
    };

    const showStep = (stepNumber) => {
        steps.forEach(step => step.classList.remove('active'));
        const activeStep = document.querySelector(`.form-step[data-step="${stepNumber}"]`);
        if (activeStep) activeStep.classList.add('active');

        progressSteps.forEach((pStep, index) => {
            pStep.classList.toggle('active', index < stepNumber);
        });

        if (prevBtn) prevBtn.classList.toggle('hidden', stepNumber === 1);

        if (stepNumber === totalSteps) {
            if (navigationBtnGroup) navigationBtnGroup.style.display = 'none';
            if (originalBtnGroup) originalBtnGroup.style.display = 'flex';
        } else {
            if (navigationBtnGroup) navigationBtnGroup.style.display = 'flex';
            if (originalBtnGroup) originalBtnGroup.style.display = 'none';
        }
    };

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (validateCurrentStep() && currentStep < totalSteps) {
                currentStep++;
                showStep(currentStep);
            }
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentStep > 1) {
                currentStep--;
                showStep(currentStep);
            }
        });
    }

    showStep(currentStep);

    const requiredInputs = form.querySelectorAll('input[required], textarea[required], select[required]');

    function validarFormularioCompleto() {
        for (const input of requiredInputs) {
            if (input.type === 'checkbox' && !input.checked) return false;
            if (input.type !== 'radio' && input.type !== 'checkbox' && input.value !== undefined && !input.value.trim()){
                 return false;
            }
        }
        return true;
    }

    generarRemitoBtn.addEventListener('click', async () => {
        if (!validarFormularioCompleto()) {
            Toastify({ text: "Por favor, complete todos los campos requeridos (*)", duration: 3000, gravity: "top", position: "right", style: { background: "linear-gradient(to right, #dc3545, #c31432)" } }).showToast();
            return;
        }

        if (!currentUser) {
            Toastify({ text: "Error: No se ha podido verificar el usuario. Por favor, inicie sesión de nuevo.", duration: 3000, gravity: "top", position: "right", style: { background: "linear-gradient(to right, #dc3545, #c31432)" } }).showToast();
            return;
        }

        generarRemitoBtn.disabled = true;
        generarRemitoBtn.classList.add('loading');

        const datosRemito = {
            tallerId: currentUser.uid,
            clienteNombre: document.getElementById('clienteNombre').value.trim(),
            clienteTelefono: document.getElementById('clienteTelefono').value.trim(),
            clienteEmail: document.getElementById('clienteEmail').value.trim(),
            equipoTipo: document.getElementById('equipoTipo').value,
            equipoColor: document.getElementById('equipoColor').value.trim(),
            equipoMarca: document.getElementById('equipoMarca').value.trim(),
            equipoModelo: document.getElementById('equipoModelo').value.trim(),
            equipoSerie: document.getElementById('equipoSerie').value.trim(),
            diagnosticoCarga: document.querySelector('input[name="diag_carga"]:checked')?.value || 'No especificado',
            diagnosticoEnciende: document.querySelector('input[name="diag_enciende"]:checked')?.value || 'No especificado',
            diagnosticoGolpeado: document.querySelector('input[name="diag_golpeado"]:checked')?.value || 'No especificado',
            diagnosticoMojado: document.querySelector('input[name="diag_mojado"]:checked')?.value || 'No especificado',
            accesoriosEntregados: Array.from(document.querySelectorAll('#accesoriosChecklist input[type=checkbox]:checked')).map(cb => cb.name),
            estadoCelular: document.getElementById('estadoCelular').value.trim(),
            fallaCategoria: document.getElementById('fallaCategoria').value,
            descripcionFalla: document.getElementById('descripcionFalla').value.trim(),
            claveContraseña: document.getElementById('claveContraseña').value.trim(),
            presupuestoInicial: document.getElementById('presupuestoInicial').value.trim(),
            aceptaTerminos: document.getElementById('terminosCondiciones').checked,
            fechaCreacion: serverTimestamp(),
            estadoReparacion: 'Recibido',
            historial: [],
            archivado: false
        };

        try {
            const docRef = await addDoc(collection(db, "remitos"), datosRemito);
            const nuevoNumeroRemito = docRef.id.substring(0, 6).toUpperCase();
            
            await updateDoc(docRef, { 
                numeroRemito: nuevoNumeroRemito, 
                historial: arrayUnion({ cambio: 'Equipo recibido en el taller.', fecha: new Date() }) 
            });
            
            // ===== INICIO DE LA MODIFICACIÓN =====
            const docId = docRef.id;
            const cliente = encodeURIComponent(datosRemito.clienteNombre);
            
            // Redirigimos pasando toda la info necesaria en la URL
            window.location.href = `confirmacion.html?docId=${docId}&remitoNo=${nuevoNumeroRemito}&cliente=${cliente}`;
            // ===== FIN DE LA MODIFICACIÓN =====

        } catch (e) {
            console.error("Error al agregar el documento: ", e);
            Toastify({ text: "Error al guardar el registro.", duration: 3000, gravity: "top", position: "right", style: { background: "linear-gradient(to right, #dc3545, #c31432)" } }).showToast();
        } finally {
            generarRemitoBtn.disabled = false;
            generarRemitoBtn.classList.remove('loading');
        }
    });
});